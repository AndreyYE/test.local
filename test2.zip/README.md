# test.local
Тестовое задание.
При развертывание проекта обязательно установите данные вашей mysql в файл  environment.php.
Дамп базы данных это test.sql
Видео инструкция по развертывают тестового проекта на хостинге  https://www.youtube.com/watch?v=WbtayAmy5WM&feature=youtu.be

