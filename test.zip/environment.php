<?php
return [
  //DB
    'DB_SERVER_NAME'=>'localhost',
    'DB_PORT'=>3306,
    'DB_USER_NAME'=>'root',
    'DB_PASSWORD'=>'',
    'DB_NAME'=>'test1',
];